<ul>
    <li><a href="milhar.php"><button>milhar</button></a></li>
    <li><a href="simples.php"><button>simples</button></a></li>
</ul>